from django.db import models

class Admin(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=100,blank=False,unique=True)
    password = models.CharField(max_length=100,blank=False)

    class Meta:
        db_table = "admin_table"

class Student(models.Model):
    id = models.AutoField(primary_key=True)
    student_id = models.BigIntegerField(blank=False,unique=True)
    fullname = models.CharField(max_length=100,blank=False)
    gender = models.CharField(max_length=20,blank=False)
    department = models.CharField(max_length=100,blank=False)
    program = models.CharField(max_length=100, blank=False)
    semester = models.CharField(max_length=10,blank=False)
    year = models.IntegerField(blank=False)
    password = models.CharField(max_length=100,blank=False,default="klu123e")
    email = models.CharField(max_length=100,blank=False,unique=True)
    contact = models.CharField(max_length=20,blank=False,unique=True)

    class meta:
        db_table= "student_table"